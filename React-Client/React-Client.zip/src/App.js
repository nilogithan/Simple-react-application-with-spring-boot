import React from 'react';
import './App.css';
import ProjectIndex from "./component/Defect/ProjectIndex"
import MiniDrawer from "./component/Test/test"

function App() {
  return (
    <div>
    <MiniDrawer/>
    <ProjectIndex/>
    {/* <h1>hello</h1> */}
    </div>
  );
}

export default App;
